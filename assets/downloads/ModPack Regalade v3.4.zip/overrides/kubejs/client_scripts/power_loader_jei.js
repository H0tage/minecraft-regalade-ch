// Le serveur réserve le chargement des chunks aux chargeurs en laiton raccordés aux gares.
RecipeViewerEvents.removeEntriesCompletely('item', event => {
  event.remove('create_power_loader:andesite_chunk_loader')
  event.remove('create_power_loader:empty_andesite_chunk_loader')
})
