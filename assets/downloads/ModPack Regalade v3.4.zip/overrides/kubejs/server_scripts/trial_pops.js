LootJS.modifiers(event => {
    const pops = [
        'regaladepop:lorexe_pop',
        'regaladepop:icesaiyan_pop',
        'regaladepop:hotage_pop',
        'regaladepop:kemmler_pop',
        'regaladepop:nuizarre_pop',
        'regaladepop:johnvador_pop',
        'regaladepop:alchara_pop',
        'regaladepop:psykojace_pop',
        'regaladepop:berenul_pop',
        'regaladepop:roshynn_pop',
        'regaladepop:strenz33_pop',
        'regaladepop:izumiii01_pop',
        'regaladepop:thebali_pop',
        'regaladepop:azonoth_pop'
    ];

    event.addTableModifier([
        "minecraft:chests/trial_chambers/reward",
        "minecraft:chests/trial_chambers/reward_ominous"
    ])
    .pool(pool => {
        pool.rolls(1);
        pops.forEach(popId => {
            pool.addEntry(LootEntry.of(popId)); 
        });
    });
});