const pops = [
    { id: 'lorexe_pop', name: 'Lorexe Pop' },
    { id: 'hotage_pop', name: 'H0tage Pop' },
    { id: 'icesaiyan_pop', name: 'IceSaiyan Pop' },
    { id: 'kemmler_pop', name: 'Kemmler Pop' },
    { id: 'nuizarre_pop', name: 'Nuizarre Pop' },
    { id: 'johnvador_pop', name: 'johnvador Pop' },
    { id: 'alchara_pop', name: 'Alchara Pop' },
    { id: 'psykojace_pop', name: 'PsykoJace Pop' },
    { id: 'berenul_pop', name: 'Berenul Pop' },
    { id: 'roshynn_pop', name: 'RoshynN Pop' },
    { id: 'strenz33_pop', name: 'strenz33 Pop' },
    { id: 'izumiii01_pop', name: 'Izumiii01 Pop' },
    { id: 'thebali_pop', name: 'TheBali Pop' },
    { id: 'azonoth_pop', name: 'Azzonoth Pop' }
];

StartupEvents.registry('block', event => {
	pops.forEach(pop => {
		event.create(`regaladepop:${pop.id}`, 'cardinal') 
			.displayName(`§d${pop.name}`)
			.soundType('candle')
			.hardness(0)
			.defaultCutout()
			.resistance(1.0)
			.requiresTool(false)
			.tag('minecraft:mineable/pickaxe')
			.box(2, 0, 2, 14, 16, 14);
	});
});