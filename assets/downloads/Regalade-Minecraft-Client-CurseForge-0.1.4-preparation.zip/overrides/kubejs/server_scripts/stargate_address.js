// Clic droit sur une porte avec la clé Create : affiche son adresse dans le chat.
BlockEvents.rightClicked(event => {
  if (event.hand.toString() !== 'MAIN_HAND') return
  if (event.item.id !== 'create:wrench') return

  const blockId = String(event.block.id)
  const isStargateBlock = blockId.startsWith('sgjourney:') && blockId.includes('stargate')
  if (!isStargateBlock) return

  // Empêche la clé Create de modifier ou démonter une pièce de la porte.
  event.cancel()

  const data = event.block.entityData
  if (!data || !data.contains('9_chevron_address')) {
    event.player.tell('§6[Stargate]§r Adresse introuvable : vise le bloc principal ou le bloc de base d’une porte formée.')
    return
  }

  const addressData = data.getIntArray('9_chevron_address')
  if (!addressData || addressData.length === 0) {
    event.player.tell('§6[Stargate]§r Cette porte ne possède pas encore d’adresse.')
    return
  }

  const address = []
  for (let i = 0; i < addressData.length; i++) {
    address.push(addressData[i])
  }

  event.player.tell(`§6[Stargate]§r Adresse : §b-${address.join('-')}-`)
})
