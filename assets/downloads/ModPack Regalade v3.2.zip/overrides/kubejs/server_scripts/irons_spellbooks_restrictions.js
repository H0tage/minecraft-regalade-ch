// Restrictions d'équilibrage Régalade pour Iron's Spells 'n Spellbooks.
// Les sorts sont désactivés par les fichiers de configuration datapack ; ce
// script couvre les objets physiques et les anciens exemplaires déjà créés.
const REGALADE_DISABLED_IRON_ITEMS = [
    'irons_spellbooks:portal_frame',
    'irons_spellbooks:teleportation_amulet'
]

ServerEvents.recipes(event => {
    REGALADE_DISABLED_IRON_ITEMS.forEach(item => {
        event.remove({ output: item })
    })
})

BlockEvents.placed('irons_spellbooks:portal_frame', event => event.cancel())
BlockEvents.rightClicked('irons_spellbooks:portal_frame', event => event.cancel())

ItemEvents.rightClicked(REGALADE_DISABLED_IRON_ITEMS, event => event.cancel())

// L'amulette est un Curio : annuler le clic droit ne suffit pas, car elle peut
// aussi être glissée directement dans son emplacement d'accessoire.
const RegaladeIronTriState = Java.loadClass('net.neoforged.neoforge.common.util.TriState')
const RegaladeIronItemRegistry = Java.loadClass('net.minecraft.core.registries.BuiltInRegistries')
const RegaladeIronCuriosApi = Java.loadClass('top.theillusivec4.curios.api.CuriosApi')
const RegaladeIronResourceLocation = Java.loadClass('net.minecraft.resources.ResourceLocation')
const RegaladeIronItemStack = Java.loadClass('net.minecraft.world.item.ItemStack')

NativeEvents.onEvent('top.theillusivec4.curios.api.event.CurioCanEquipEvent', event => {
    const itemId = String(RegaladeIronItemRegistry.ITEM.getKey(event.getStack().getItem()))

    if (itemId === 'irons_spellbooks:teleportation_amulet') {
        event.setEquipResult(RegaladeIronTriState.FALSE)
    }
})

// Une ancienne amulette déjà équipée est rendue au joueur à sa connexion.
PlayerEvents.loggedIn(event => {
    const inventory = RegaladeIronCuriosApi.getCuriosInventory(event.player)
    if (inventory.isEmpty()) {
        return
    }

    const handler = inventory.get()
    const amulet = RegaladeIronItemRegistry.ITEM.get(
        RegaladeIronResourceLocation.parse('irons_spellbooks:teleportation_amulet')
    )
    const equipped = handler.findFirstCurio(amulet)
    if (equipped.isEmpty()) {
        return
    }

    const slot = equipped.get()
    const stack = slot.stack().copy()
    const context = slot.slotContext()
    handler.setEquippedCurio(context.identifier(), context.index(), RegaladeIronItemStack.EMPTY)

    if (!event.player.getInventory().add(stack)) {
        event.player.drop(stack, false)
    }
})
