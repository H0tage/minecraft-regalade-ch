// Create: Chimneys 1.4.1 enregistre ses blocs et leurs recettes, mais ne les
// expose pas correctement dans les onglets créatifs. JEI ne les découvre donc
// pas automatiquement. Cette liste réinjecte les huit BlockItems dans JEI.
RecipeViewerEvents.addEntries('item', event => {
  [
    'create_chimneys:chimney',
    'create_chimneys:chimney_copper',
    'create_chimneys:chimney_stone_bricks',
    'create_chimneys:chimney_iron',
    'create_chimneys:chimney_bricks',
    'create_chimneys:chimney_deepslate_bricks',
    'create_chimneys:chimney_mud_bricks',
    'create_chimneys:chimney_nether_bricks'
  ].forEach(item => event.add(item))
})
