// Masque complètement les sacs désactivés afin qu'ils ne polluent ni JEI,
// ni les recherches par recettes et utilisations.
RecipeViewerEvents.removeEntriesCompletely('item', event => {
  ;[
    'camping:small_backpack',
    'camping:large_backpack',
    'camping:wanderer_backpack',
    'camping:wanderer_bag',
    'camping:sheepbag',
    'camping:goodybag',
    'camping:enderbag',
    'camping:enderpack'
  ].forEach(item => event.remove(item))
})
