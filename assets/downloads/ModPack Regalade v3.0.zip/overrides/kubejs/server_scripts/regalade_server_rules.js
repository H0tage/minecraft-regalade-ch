// Règles communes du serveur Régalade.
// - Empêche la propagation accidentelle du feu.
// - Migre une seule fois les anciennes missions récompensées en diamants.
// - Renouvelle ensuite les missions chaque dimanche à minuit en Suisse.

const RegaladeZoneId = Java.loadClass('java.time.ZoneId')
const RegaladeZonedDateTime = Java.loadClass('java.time.ZonedDateTime')
const REGALADE_ZURICH = RegaladeZoneId.of('Europe/Zurich')

const REGALADE_MISSION_MIGRATED = 'regaladeBrassworksSprocketMigrationV1'
const REGALADE_MISSION_MIGRATION_DELAY = 'regaladeBrassworksMigrationDelay'
const REGALADE_MISSION_WEEK = 'regaladeBrassworksMissionWeek'

let regaladeMissionClock = 0

function regaladeCurrentMissionWeek() {
  const now = RegaladeZonedDateTime.now(REGALADE_ZURICH)
  const daysSinceSunday = now.getDayOfWeek().getValue() % 7
  return now.toLocalDate().minusDays(daysSinceSunday).toString()
}

function regaladeReassignMissions(server, player, weekKey, reason) {
  server.runCommandSilent(`missions reassign category 1 ${player.username}`)
  player.persistentData.putString(REGALADE_MISSION_WEEK, weekKey)
  console.info(`[Régalade] Missions réassignées pour ${player.username} (${reason}).`)
}

ServerEvents.loaded(event => {
  event.server.runCommandSilent('gamerule doFireTick false')
})

ServerEvents.tick(event => {
  // Une vérification par seconde suffit et évite de parcourir les joueurs à chaque tick.
  regaladeMissionClock++
  if (regaladeMissionClock < 20) return
  regaladeMissionClock = 0

  const weekKey = regaladeCurrentMissionWeek()

  event.server.players.forEach(player => {
    const data = player.persistentData

    // Laisser quelques secondes au mod pour initialiser les missions à la connexion.
    if (!data.getBoolean(REGALADE_MISSION_MIGRATED)) {
      const delay = data.getInt(REGALADE_MISSION_MIGRATION_DELAY) + 1
      data.putInt(REGALADE_MISSION_MIGRATION_DELAY, delay)
      if (delay < 3) return

      regaladeReassignMissions(event.server, player, weekKey, 'migration diamant vers sprocket')
      data.putBoolean(REGALADE_MISSION_MIGRATED, true)
      data.remove(REGALADE_MISSION_MIGRATION_DELAY)
      return
    }

    // La clé change à 00:00 le dimanche dans le fuseau Europe/Zurich.
    // Les joueurs hors ligne sont réassignés dès leur prochaine connexion.
    if (data.getString(REGALADE_MISSION_WEEK) !== weekKey) {
      regaladeReassignMissions(event.server, player, weekKey, 'renouvellement hebdomadaire')
    }
  })
})
