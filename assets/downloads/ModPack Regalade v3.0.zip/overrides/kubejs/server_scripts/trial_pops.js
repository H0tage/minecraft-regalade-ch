LootJS.modifiers(event => {
    const pops = [
        'regaladepop:lorexe_pop',
        'regaladepop:icesaiyan_pop',
        'regaladepop:hotage_pop'
    ];

    event.addTableModifier([
        "minecraft:chests/trial_chambers/reward",
        "minecraft:chests/trial_chambers/reward_ominous"
    ])
    .pool(pool => {
        pool.rolls(1);
        pops.forEach(popId => {
            pool.addEntry(LootEntry.of(popId)); 
        });
    });
});