// Removes shortcuts that would bypass the communal refinery.
// Native recipes replaced by datapack JSON keep their original IDs and need no removal.

ServerEvents.recipes(event => {
  event.remove({ id: 'sgjourney:reaction_chamber_from_fusion_core' });
  event.remove({ id: 'sgjourney:naquadah_ingot_from_smelting' });
  event.remove({ id: 'sgjourney:naquadah_ingot_from_blasting' });
  event.remove({ id: 'sgjourney:naquadah_ingot_from_nuggets' });
  event.remove({ id: 'sgjourney:naquadah_ingot_from_naquadah_block' });
  event.remove({ id: 'sgjourney:naquadah_from_blasting' });
  event.remove({ id: 'sgjourney:refined_naquadah_from_blasting' });
  event.remove({ id: 'sgjourney:raw_naquadah_from_raw_naquadah_block' });
  event.remove({ id: 'sgjourney:raw_naquadah_block' });
  event.remove({ id: 'sgjourney:pure_naquadah_from_pure_naquadah_block' });
  event.remove({ id: 'sgjourney:pure_naquadah_block' });
  event.remove({ id: 'sgjourney:naquadah_generator_core' });
  event.remove({ id: 'sgjourney:naquadah_generator_mark_i' });
  event.remove({ id: 'sgjourney:naquadah_generator_mark_ii' });
  event.remove({ id: 'sgjourney:naquadah_power_cell' });
  event.remove({ id: 'sgjourney:naquadah_fuel_rod' });
  event.remove({ id: 'sgjourney:naquadah_fuel_rod_refill' });
  event.remove({ id: 'sgjourney:zpm_holder' });
  event.remove({ id: 'sgjourney:zpm_hub' });
  event.remove({ id: 'sgjourney:zpm_plug' });
  event.remove({ id: 'sgjourney:zpm_port' });
  event.remove({ id: 'sgjourney:heavy_naquadah_liquidizer' });
  event.remove({ id: 'sgjourney:naquadah_heavy_liquidizing/heavy_liquid_naquadah_from_pure_naquadah' });
});
