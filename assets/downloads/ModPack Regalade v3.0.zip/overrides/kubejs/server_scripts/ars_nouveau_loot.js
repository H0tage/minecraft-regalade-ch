LootJS.modifiers(event => {
    event.addTableModifier(LootType.CHEST)
        .removeLoot([
            'ars_nouveau:warp_scroll',
            'ars_nouveau:stable_warp_scroll'
        ])
})
