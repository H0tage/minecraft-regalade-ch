// Let’s Do Camping ajoute huit sacs qui doublonnent avec Sophisticated Backpacks.
// Ils sont retirés des recettes, du butin et des ventes du marchand ambulant.
const REGALADE_DISABLED_CAMPING_BACKPACKS = [
  'camping:small_backpack',
  'camping:large_backpack',
  'camping:wanderer_backpack',
  'camping:wanderer_bag',
  'camping:sheepbag',
  'camping:goodybag',
  'camping:enderbag',
  'camping:enderpack'
]

ServerEvents.recipes(event => {
  REGALADE_DISABLED_CAMPING_BACKPACKS.forEach(item => {
    event.remove({ output: item })
  })
})

LootJS.modifiers(event => {
  // Le mod injecte directement trois sacs dans des coffres avec des
  // Global Loot Modifiers. Les cinq injections sont désactivées à la source.
  ;[
    'camping:spawn_bonus_chest_modifier',
    'camping:stronghold_crossing_modifier',
    'camping:stronghold_library_modifier',
    'camping:stronghold_corridor_modifier',
    'camping:end_city_treasure_modifier'
  ].forEach(modifier => event.removeGlobalModifiers(modifier))

  // Sécurité supplémentaire pour les tables déjà modifiées par un autre mod.
  ;[
    'minecraft:chests/spawn_bonus_chest',
    'minecraft:chests/stronghold_crossing',
    'minecraft:chests/stronghold_library',
    'minecraft:chests/stronghold_corridor',
    'minecraft:chests/end_city_treasure'
  ].forEach(table => {
    REGALADE_DISABLED_CAMPING_BACKPACKS.forEach(item => {
      event.addTableModifier(table).removeLoot(item)
    })
  })

  // Le Goodybag est normalement accordé par un défi du mod.
  event.addTableModifier('camping:advancements/goodybag').removeLoot('camping:goodybag')
})

// Les deux variantes Wanderer sont ajoutées directement aux offres du
// marchand ambulant par le code du mod, sans recette ni table de butin.
const REGALADE_ITEM_REGISTRY = Java.loadClass('net.minecraft.core.registries.BuiltInRegistries')

EntityEvents.spawned('minecraft:wandering_trader', event => {
  const offers = event.entity.getOffers()

  for (let index = offers.size() - 1; index >= 0; index--) {
    const result = offers.get(index).getResult()
    const itemId = String(REGALADE_ITEM_REGISTRY.ITEM.getKey(result.getItem()))

    if (REGALADE_DISABLED_CAMPING_BACKPACKS.includes(itemId)) {
      offers.remove(index)
    }
  }
})
