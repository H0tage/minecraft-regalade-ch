ServerEvents.recipes(event => {
    event.remove({ output: 'ars_nouveau:warp_scroll' })
    event.remove({ output: 'ars_nouveau:stable_warp_scroll' })
    event.remove({ output: 'ars_nouveau:ritual_warping' })
    event.remove({ output: 'ars_nouveau:thread_starbuncle' })
})
