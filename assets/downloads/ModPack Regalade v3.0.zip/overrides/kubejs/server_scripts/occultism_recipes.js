ServerEvents.recipes(event => {
    event.remove({ id: 'occultism:ritual/craft_stable_wormhole' })
    event.remove({ id: 'occultism:ritual/craft_entity_wormhole' })
    event.remove({ id: 'occultism:ritual/craft_stable_wormhole_dark' })
    event.remove({ id: 'occultism:ritual/craft_entity_wormhole_dark' })
    event.remove({ id: 'occultism:ritual/craft_vitality_compass' })

    event.remove({ output: 'occultism:stable_wormhole' })
    event.remove({ output: 'occultism:stable_wormhole_dark' })
    event.remove({ output: 'occultism:entity_wormhole' })
    event.remove({ output: 'occultism:entity_wormhole_dark' })
    event.remove({ output: 'occultism:vitality_compass' })
})
