const blockedItems = [
    'ars_nouveau:warp_scroll',
    'ars_nouveau:stable_warp_scroll',
    'ars_nouveau:ritual_warping',
    'ars_nouveau:thread_starbuncle'
]

ItemEvents.rightClicked(blockedItems, event => {
    event.cancel()
})
