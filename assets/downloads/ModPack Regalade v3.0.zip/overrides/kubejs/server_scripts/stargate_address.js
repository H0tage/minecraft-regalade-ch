// Clic droit sur une porte avec la clé Create : affiche son adresse dans le chat.
BlockEvents.rightClicked(event => {
  if (event.hand.toString() !== 'MAIN_HAND') return
  if (event.item.id !== 'create:wrench') return
  if (event.block.id.split(':')[0] !== 'sgjourney') return

  let data = event.block.entityData
  if (!data || !data.contains('9_chevron_address')) return

  let arr = data.getIntArray('9_chevron_address')
  if (!arr || arr.length === 0) return

  let parts = []
  for (let i = 0; i < arr.length; i++) parts.push(arr[i])

  let address = '-' + parts.join('-') + '-'
  event.player.tell(`§6[Stargate]§r Adresse : §b${address}`)
  event.cancel()
})
