ItemEvents.modifyTooltips(event => {
    
    event.add(

        '@regaladepop',
        [
        '§7Found In Trial Vaults§r'
        ]
    );

});