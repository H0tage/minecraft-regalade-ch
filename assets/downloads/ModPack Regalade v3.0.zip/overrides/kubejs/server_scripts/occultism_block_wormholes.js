const disabledWormholes = [
    'occultism:stable_wormhole',
    'occultism:stable_wormhole_dark',
    'occultism:entity_wormhole',
    'occultism:entity_wormhole_dark'
]

disabledWormholes.forEach(block => {
    BlockEvents.placed(block, event => event.cancel())
    BlockEvents.rightClicked(block, event => event.cancel())
})

ItemEvents.rightClicked('occultism:vitality_compass', event => event.cancel())
