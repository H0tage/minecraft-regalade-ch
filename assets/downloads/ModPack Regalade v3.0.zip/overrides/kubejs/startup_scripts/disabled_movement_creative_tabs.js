const disabledArsMovement = [
    'ars_nouveau:warp_scroll',
    'ars_nouveau:stable_warp_scroll',
    'ars_nouveau:ritual_warping',
    'ars_nouveau:thread_starbuncle'
]

const disabledOccultismMovement = [
    'occultism:stable_wormhole',
    'occultism:stable_wormhole_dark',
    'occultism:entity_wormhole',
    'occultism:entity_wormhole_dark',
    'occultism:vitality_compass'
]

StartupEvents.modifyCreativeTab('ars_nouveau:general', event => {
    disabledArsMovement.forEach(item => event.remove(item))
})

StartupEvents.modifyCreativeTab('occultism:occultism', event => {
    disabledOccultismMovement.forEach(item => event.remove(item))
})
