// Generated from the canonical Stargate design documents.
// Minecraft 1.21.1 / NeoForge / KubeJS 2101.7.2.

StartupEvents.registry('item', event => {
  event.create('amethyst_powder').displayName("Amethyst Powder").maxStackSize(64);
  event.create('crystalline_matrix').displayName("Crystalline Matrix").maxStackSize(64);
  event.create('refractory_briquette').displayName("Refractory Briquette").maxStackSize(64);
  event.create('catalytic_flux').displayName("Catalytic Flux").maxStackSize(64);
  event.create('unstable_naquadah_slag').displayName("Unstable Naquadah Slag").maxStackSize(64);
  event.create('raw_naquadah_briquette').displayName("Raw Naquadah Briquette").maxStackSize(64);
  event.create('calcined_naquadah').displayName("Calcined Naquadah").maxStackSize(64);
  event.create('impure_naquadah_dust').displayName("Impure Naquadah Dust").maxStackSize(64);
  event.create('purified_naquadah_granule').displayName("Purified Naquadah Granule").maxStackSize(64);
  event.create('cryostabilized_naquadah_crystal').displayName("Cryostabilized Naquadah Crystal").maxStackSize(64);
  event.create('incomplete_naquadah_billet').displayName("Incomplete Naquadah Billet").maxStackSize(64);
  event.create('stabilized_naquadah_billet').displayName("Stabilized Naquadah Billet").maxStackSize(64);
  event.create('dormant_naquadah_ingot').displayName("Dormant Naquadah Ingot").maxStackSize(64);
  event.create('incomplete_stargate_ring_segment').displayName("Incomplete Stargate Ring Segment").maxStackSize(64);
  event.create('incomplete_stargate_chevron').displayName("Incomplete Stargate Chevron").maxStackSize(64);
  event.create('naquadah_plate').displayName("Naquadah Plate").maxStackSize(64);
});
