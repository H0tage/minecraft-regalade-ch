const disabledArsMovement = [
    'ars_nouveau:warp_scroll',
    'ars_nouveau:stable_warp_scroll',
    'ars_nouveau:ritual_warping',
    'ars_nouveau:thread_starbuncle'
]

const disabledOccultismMovement = [
    'occultism:stable_wormhole',
    'occultism:stable_wormhole_dark',
    'occultism:entity_wormhole',
    'occultism:entity_wormhole_dark',
    'occultism:vitality_compass'
]

const disabledIronMovement = [
    'irons_spellbooks:portal_frame',
    'irons_spellbooks:teleportation_amulet'
]

const disabledIronSpells = [
    'irons_spellbooks:recall',
    'irons_spellbooks:pocket_dimension',
    'irons_spellbooks:portal',
    'irons_spellbooks:angel_wing',
    'irons_spellbooks:invisibility',
    'irons_spellbooks:summon_ender_chest',
    'irons_spellbooks:spectral_hammer'
]

StartupEvents.modifyCreativeTab('ars_nouveau:general', event => {
    disabledArsMovement.forEach(item => event.remove(item))
})

StartupEvents.modifyCreativeTab('occultism:occultism', event => {
    disabledOccultismMovement.forEach(item => event.remove(item))
})

StartupEvents.modifyCreativeTab('irons_spellbooks:spellbook_blocks', event => {
    event.remove('irons_spellbooks:portal_frame')
})

StartupEvents.modifyCreativeTab('irons_spellbooks:spellbook_equipment', event => {
    event.remove('irons_spellbooks:teleportation_amulet')
})

StartupEvents.modifyCreativeTab('minecraft:functional_blocks', event => {
    event.remove('irons_spellbooks:portal_frame')
})

// Les parchemins partagent tous le même identifiant d'objet. Le filtre doit
// donc lire le sort stocké dans chaque ItemStack au lieu de masquer tous les
// parchemins d'Iron's.
StartupEvents.modifyCreativeTab('irons_spellbooks:spellbook_scrolls', event => {
    const SpellContainer = Java.loadClass('io.redspace.ironsspellbooks.api.spells.ISpellContainer')

    event.remove(stack => {
        if (!SpellContainer.isSpellContainer(stack)) {
            return false
        }

        const container = SpellContainer.get(stack)
        if (container.isEmpty()) {
            return false
        }

        const spellId = String(container.getSpellAtIndex(0).getSpell().getSpellId())
        return disabledIronSpells.includes(spellId)
    })
})
