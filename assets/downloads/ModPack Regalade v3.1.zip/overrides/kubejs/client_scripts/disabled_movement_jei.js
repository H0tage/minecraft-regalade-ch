// Masque les objets de déplacement désactivés dans le pack ainsi que leurs
// recettes et utilisations. Les boussoles vanilla restent visibles : seule
// leur fonction de configuration des Entity Wormholes est rendue inaccessible.
RecipeViewerEvents.removeEntriesCompletely('item', event => {
  ;[
    'ars_nouveau:warp_scroll',
    'ars_nouveau:stable_warp_scroll',
    'ars_nouveau:ritual_warping',
    'ars_nouveau:thread_starbuncle',
    'irons_spellbooks:portal_frame',
    'irons_spellbooks:teleportation_amulet',
    'occultism:stable_wormhole',
    'occultism:stable_wormhole_dark',
    'occultism:entity_wormhole',
    'occultism:entity_wormhole_dark',
    'occultism:vitality_compass'
  ].forEach(item => event.remove(item))
})
